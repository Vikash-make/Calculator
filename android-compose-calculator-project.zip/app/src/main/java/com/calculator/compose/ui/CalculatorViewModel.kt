package com.calculator.compose.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.calculator.compose.domain.CalculatorEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface CalculatorAction {
    data class Number(val digit: String) : CalculatorAction
    data class Operator(val op: String) : CalculatorAction
    object Decimal : CalculatorAction
    object Calculate : CalculatorAction
    object ClearAll : CalculatorAction
    object ClearEntry : CalculatorAction
    object Delete : CalculatorAction
    object Percentage : CalculatorAction
    object PlusMinus : CalculatorAction
    object ToggleHistory : CalculatorAction
    object ClearHistory : CalculatorAction
    data class RecallHistory(val entry: CalculationHistoryEntry) : CalculatorAction
}

class CalculatorViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    fun onAction(action: CalculatorAction) {
        when (action) {
            is CalculatorAction.Number -> handleNumberInput(action.digit)
            is CalculatorAction.Operator -> handleOperatorInput(action.op)
            is CalculatorAction.Decimal -> handleDecimalInput()
            is CalculatorAction.Calculate -> handleCalculate()
            is CalculatorAction.ClearAll -> handleClearAll()
            is CalculatorAction.ClearEntry -> handleClearEntry()
            is CalculatorAction.Delete -> handleDelete()
            is CalculatorAction.Percentage -> handlePercentage()
            is CalculatorAction.PlusMinus -> handlePlusMinus()
            is CalculatorAction.ToggleHistory -> {
                _uiState.update { it.copy(isHistoryOpen = !it.isHistoryOpen) }
            }
            is CalculatorAction.ClearHistory -> {
                _uiState.update { it.copy(historyList = emptyList(), isHistoryOpen = false) }
            }
            is CalculatorAction.RecallHistory -> {
                _uiState.update {
                    it.copy(
                        expression = action.entry.result.replace(",", ""),
                        formattedDisplayExpression = action.entry.result,
                        previewResult = "",
                        errorMessage = null,
                        isEvaluated = true,
                        isHistoryOpen = false
                    )
                }
            }
        }
    }

    private fun handleNumberInput(digit: String) {
        _uiState.update { state ->
            val newExpr = if (state.isEvaluated || state.errorMessage != null) {
                digit
            } else {
                val tokens = CalculatorEngine.tokenize(state.expression)
                val lastToken = tokens.lastOrNull() ?: ""
                // Avoid redundant leading zeroes like "00" or "05"
                if (lastToken == "0") {
                    state.expression.dropLast(1) + digit
                } else {
                    state.expression + digit
                }
            }

            val formatted = CalculatorEngine.formatDisplayExpression(newExpr)
            val preview = computeLivePreview(newExpr)

            state.copy(
                expression = newExpr,
                formattedDisplayExpression = formatted,
                previewResult = preview,
                errorMessage = null,
                isEvaluated = false
            )
        }
    }

    private fun handleOperatorInput(op: String) {
        val normOp = CalculatorEngine.normalizeOperator(op) ?: return

        _uiState.update { state ->
            var expr = state.expression

            // If expression was evaluated, continue operating on result
            if (state.isEvaluated) {
                expr = state.previewResult.ifEmpty { state.expression }.replace(",", "")
            }

            if (expr.isEmpty()) {
                if (normOp == "−") {
                    return@update state.copy(
                        expression = "−",
                        formattedDisplayExpression = "−",
                        previewResult = "",
                        errorMessage = null,
                        isEvaluated = false
                    )
                }
                return@update state
            }

            val lastChar = expr.last().toString()

            // Operator Stacking: Replace existing operator at the end
            val updatedExpr = if (CalculatorEngine.isOperator(lastChar)) {
                expr.dropLast(1) + normOp
            } else if (lastChar == ".") {
                expr.dropLast(1) + normOp
            } else {
                expr + normOp
            }

            val formatted = CalculatorEngine.formatDisplayExpression(updatedExpr)

            state.copy(
                expression = updatedExpr,
                formattedDisplayExpression = formatted,
                previewResult = computeLivePreview(updatedExpr),
                errorMessage = null,
                isEvaluated = false
            )
        }
    }

    private fun handleDecimalInput() {
        _uiState.update { state ->
            if (state.isEvaluated || state.expression.isEmpty() || state.errorMessage != null) {
                return@update state.copy(
                    expression = "0.",
                    formattedDisplayExpression = "0.",
                    previewResult = "",
                    errorMessage = null,
                    isEvaluated = false
                )
            }

            val lastChar = state.expression.last().toString()
            if (CalculatorEngine.isOperator(lastChar)) {
                val newExpr = state.expression + "0."
                return@update state.copy(
                    expression = newExpr,
                    formattedDisplayExpression = CalculatorEngine.formatDisplayExpression(newExpr),
                    errorMessage = null,
                    isEvaluated = false
                )
            }

            // Inspect last number token to prevent multiple decimals (e.g. block "5.2.3")
            val tokens = CalculatorEngine.tokenize(state.expression)
            val lastToken = tokens.lastOrNull() ?: ""
            if (lastToken.contains(".")) {
                return@update state // block duplicate decimal point
            }

            val newExpr = state.expression + "."
            state.copy(
                expression = newExpr,
                formattedDisplayExpression = CalculatorEngine.formatDisplayExpression(newExpr),
                errorMessage = null,
                isEvaluated = false
            )
        }
    }

    private fun handleCalculate() {
        _uiState.update { state ->
            if (state.expression.isBlank()) return@update state

            val eval = CalculatorEngine.evaluate(state.expression)
            if (eval.isSuccess) {
                val historyEntry = CalculationHistoryEntry(
                    expression = state.formattedDisplayExpression,
                    result = eval.formattedResult
                )
                state.copy(
                    expression = eval.formattedResult.replace(",", ""),
                    formattedDisplayExpression = state.formattedDisplayExpression,
                    previewResult = eval.formattedResult,
                    errorMessage = null,
                    isEvaluated = true,
                    historyList = listOf(historyEntry) + state.historyList
                )
            } else {
                state.copy(
                    errorMessage = eval.errorMessage ?: "Syntax Error",
                    isEvaluated = false
                )
            }
        }
    }

    private fun handleClearAll() {
        _uiState.update {
            it.copy(
                expression = "",
                formattedDisplayExpression = "",
                previewResult = "",
                errorMessage = null,
                isEvaluated = false
            )
        }
    }

    private fun handleClearEntry() {
        _uiState.update { state ->
            if (state.expression.isEmpty()) return@update state
            val tokens = CalculatorEngine.tokenize(state.expression)
            if (tokens.size <= 1) {
                return@update state.copy(
                    expression = "",
                    formattedDisplayExpression = "",
                    previewResult = "",
                    errorMessage = null,
                    isEvaluated = false
                )
            }
            val newExpr = tokens.dropLast(1).joinToString("")
            state.copy(
                expression = newExpr,
                formattedDisplayExpression = CalculatorEngine.formatDisplayExpression(newExpr),
                previewResult = computeLivePreview(newExpr),
                errorMessage = null,
                isEvaluated = false
            )
        }
    }

    private fun handleDelete() {
        _uiState.update { state ->
            // Safe empty state handling
            if (state.expression.isEmpty() || state.isEvaluated) {
                return@update state.copy(
                    expression = "",
                    formattedDisplayExpression = "",
                    previewResult = "",
                    errorMessage = null,
                    isEvaluated = false
                )
            }

            val newExpr = state.expression.dropLast(1)
            val formatted = CalculatorEngine.formatDisplayExpression(newExpr)
            val preview = computeLivePreview(newExpr)

            state.copy(
                expression = newExpr,
                formattedDisplayExpression = formatted,
                previewResult = preview,
                errorMessage = null,
                isEvaluated = false
            )
        }
    }

    private fun handlePercentage() {
        _uiState.update { state ->
            if (state.expression.isEmpty()) return@update state
            val lastChar = state.expression.last().toString()
            if (CalculatorEngine.isOperator(lastChar) || lastChar == "%" || lastChar == ".") {
                return@update state
            }

            val newExpr = state.expression + "%"
            val formatted = CalculatorEngine.formatDisplayExpression(newExpr)
            state.copy(
                expression = newExpr,
                formattedDisplayExpression = formatted,
                previewResult = computeLivePreview(newExpr),
                errorMessage = null,
                isEvaluated = false
            )
        }
    }

    private fun handlePlusMinus() {
        _uiState.update { state ->
            if (state.expression.isEmpty()) {
                return@update state.copy(
                    expression = "−",
                    formattedDisplayExpression = "−",
                    isEvaluated = false
                )
            }

            val tokens = CalculatorEngine.tokenize(state.expression).toMutableList()
            if (tokens.isEmpty()) return@update state

            val lastToken = tokens.last()
            if (CalculatorEngine.isOperator(lastToken)) {
                val newExpr = state.expression + "−"
                return@update state.copy(
                    expression = newExpr,
                    formattedDisplayExpression = CalculatorEngine.formatDisplayExpression(newExpr)
                )
            } else {
                val toggled = if (lastToken.startsWith("−") || lastToken.startsWith("-")) {
                    lastToken.drop(1)
                } else {
                    "−$lastToken"
                }
                tokens[tokens.size - 1] = toggled
                val newExpr = tokens.joinToString("")
                state.copy(
                    expression = newExpr,
                    formattedDisplayExpression = CalculatorEngine.formatDisplayExpression(newExpr),
                    previewResult = computeLivePreview(newExpr)
                )
            }
        }
    }

    private fun computeLivePreview(expr: String): String {
        if (expr.isEmpty()) return ""
        // Only show preview if expression contains an operator and not ending in bare operator
        val containsOperator = CalculatorEngine.OPERATORS.any { expr.contains(it) } || expr.contains("%")
        if (!containsOperator) return ""

        val eval = CalculatorEngine.evaluate(expr)
        return if (eval.isSuccess) eval.formattedResult else ""
    }
}
