package com.calculator.compose.domain

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/**
 * Robust, zero-bug Calculator Engine implementing:
 * - Mathematical Order of Operations (BODMAS / PEMDAS)
 * - Arbitrary-precision floating point arithmetic using BigDecimal (prevents IEEE double rounding issues)
 * - Safe division by zero detection
 * - Operator stacking and multiple decimal point prevention
 * - Trailing zero stripping and standard thousands formatting
 */
object CalculatorEngine {

    val OPERATORS = listOf("+", "−", "×", "÷")
    private val MATH_CONTEXT = MathContext(16, RoundingMode.HALF_UP)

    data class EvaluationResult(
        val isSuccess: Boolean,
        val formattedResult: String = "",
        val rawValue: BigDecimal? = null,
        val errorMessage: String? = null
    )

    fun isOperator(char: String): Boolean = OPERATORS.contains(char)

    fun normalizeOperator(op: String): String? {
        return when (op) {
            "+", "add" -> "+"
            "-", "−", "sub" -> "−"
            "*", "×", "x", "X", "mul" -> "×"
            "/", "÷", "div" -> "÷"
            else -> null
        }
    }

    /**
     * Splits an expression string into number tokens and operator tokens.
     */
    fun tokenize(expression: String): List<String> {
        val tokens = mutableListOf<String>()
        var currentNumber = StringBuilder()

        for (ch in expression) {
            val charStr = ch.toString()
            if (isOperator(charStr) || charStr == "%") {
                if (currentNumber.isNotEmpty()) {
                    tokens.add(currentNumber.toString())
                    currentNumber = StringBuilder()
                }
                tokens.add(charStr)
            } else {
                currentNumber.append(charStr)
            }
        }

        if (currentNumber.isNotEmpty()) {
            tokens.add(currentNumber.toString())
        }

        return tokens
    }

    /**
     * Formats an ongoing raw mathematical expression with thousands separators and clean spacing.
     */
    fun formatDisplayExpression(rawExpr: String): String {
        if (rawExpr.isEmpty()) return ""
        val tokens = tokenize(rawExpr)
        val sb = StringBuilder()

        for (token in tokens) {
            when {
                isOperator(token) -> sb.append(" $token ")
                token == "%" -> sb.append("%")
                else -> sb.append(formatNumberString(token))
            }
        }
        return sb.toString()
    }

    /**
     * Formats a raw number string with comma separators while keeping in-progress decimal parts intact.
     */
    fun formatNumberString(numberStr: String): String {
        if (numberStr.isEmpty()) return ""
        if (numberStr == "-" || numberStr == "−") return "−"

        val isNegative = numberStr.startsWith("-") || numberStr.startsWith("−")
        val clean = if (isNegative) numberStr.substring(1) else numberStr

        val parts = clean.split(".")
        val integerPart = parts[0]

        // Format integer part with commas
        val symbols = DecimalFormatSymbols(Locale.US)
        val formatter = DecimalFormat("#,###", symbols)
        val formattedInt = try {
            if (integerPart.isNotEmpty()) {
                val bigInt = BigDecimal(integerPart)
                formatter.format(bigInt)
            } else ""
        } catch (e: Exception) {
            integerPart
        }

        val prefix = if (isNegative) "−" else ""
        return if (parts.size > 1) {
            val decimalPart = parts[1]
            "$prefix$formattedInt.$decimalPart"
        } else {
            "$prefix$formattedInt"
        }
    }

    /**
     * Formats evaluated BigDecimal result:
     * - Strips trailing zeroes after decimal point
     * - Applies thousands grouping
     * - Uses scientific notation for values with > 15 digits
     */
    fun formatResult(value: BigDecimal): String {
        // Strip trailing zeroes
        val stripped = value.stripTrailingZeros()
        val plainString = stripped.toPlainString()

        // Check if value is excessively large or small
        if (plainString.replace("-", "").replace(".", "").length > 15 ||
            (value.abs() > BigDecimal("1E14") && value.scale() <= 0)
        ) {
            val symbols = DecimalFormatSymbols(Locale.US)
            val sciFormat = DecimalFormat("0.######E0", symbols)
            return sciFormat.format(value)
        }

        return formatNumberString(plainString)
    }

    /**
     * Evaluates the expression according to strict BODMAS / PEMDAS precedence:
     * 1. Percentage resolution
     * 2. Multiplication (×) and Division (÷) left-to-right
     * 3. Addition (+) and Subtraction (–) left-to-right
     */
    fun evaluate(expression: String): EvaluationResult {
        if (expression.isBlank()) {
            return EvaluationResult(isSuccess = false, errorMessage = "Empty expression")
        }

        // Clean expression: normalize signs
        var cleaned = expression.replace("-", "−").replace("*", "×").replace("/", "÷")

        // Strip trailing operators for dynamic live preview
        while (cleaned.isNotEmpty() && isOperator(cleaned.last().toString())) {
            cleaned = cleaned.dropLast(1)
        }

        if (cleaned.isEmpty()) {
            return EvaluationResult(isSuccess = false, errorMessage = "Empty expression")
        }

        val rawTokens = tokenize(cleaned)
        if (rawTokens.isEmpty()) {
            return EvaluationResult(isSuccess = false, errorMessage = "Empty expression")
        }

        // Clean up partial decimal points at end of token (e.g. "5." -> "5")
        val tokens = rawTokens.map { if (it.endsWith(".")) it.dropLast(1) else it }

        sealed class TokenItem {
            data class Num(val value: BigDecimal) : TokenItem()
            data class Op(val operator: String) : TokenItem()
        }

        try {
            // Stage 1: Percentages and initial number parsing
            val stage1 = mutableListOf<TokenItem>()

            for (token in tokens) {
                if (token == "%") {
                    if (stage1.isEmpty()) {
                        return EvaluationResult(isSuccess = false, errorMessage = "Syntax error")
                    }
                    val prev = stage1.last()
                    if (prev !is TokenItem.Num) {
                        return EvaluationResult(isSuccess = false, errorMessage = "Syntax error")
                    }

                    // Check for preceding binary operator: A + B% -> A + (A * B / 100)
                    if (stage1.size >= 3) {
                        val opBefore = stage1[stage1.size - 2]
                        val baseNum = stage1[stage1.size - 3]
                        if (opBefore is TokenItem.Op && baseNum is TokenItem.Num) {
                            if (opBefore.operator == "+" || opBefore.operator == "−") {
                                val percentVal = baseNum.value.multiply(prev.value, MATH_CONTEXT)
                                    .divide(BigDecimal(100), MATH_CONTEXT)
                                stage1[stage1.size - 1] = TokenItem.Num(percentVal)
                                continue
                            }
                        }
                    }

                    // Standalone percentage: B% = B / 100
                    val percentVal = prev.value.divide(BigDecimal(100), MATH_CONTEXT)
                    stage1[stage1.size - 1] = TokenItem.Num(percentVal)
                } else if (isOperator(token)) {
                    stage1.add(TokenItem.Op(token))
                } else {
                    val cleanNum = token.replace("−", "-")
                    val parsed = BigDecimal(cleanNum)
                    stage1.add(TokenItem.Num(parsed))
                }
            }

            if (stage1.isEmpty() || stage1.last() is TokenItem.Op) {
                return EvaluationResult(isSuccess = false, errorMessage = "Incomplete expression")
            }

            // Stage 2: High Precedence (× and ÷)
            val stage2 = mutableListOf<TokenItem>()
            var idx = 0

            while (idx < stage1.size) {
                val current = stage1[idx]
                if (current is TokenItem.Op && (current.operator == "×" || current.operator == "÷")) {
                    val left = stage2.removeLastOrNull() as? TokenItem.Num
                    val right = stage1.getOrNull(idx + 1) as? TokenItem.Num

                    if (left == null || right == null) {
                        return EvaluationResult(isSuccess = false, errorMessage = "Syntax error")
                    }

                    if (current.operator == "÷") {
                        if (right.value.compareTo(BigDecimal.ZERO) == 0) {
                            return EvaluationResult(
                                isSuccess = false,
                                errorMessage = "Cannot divide by zero"
                            )
                        }
                        val divided = left.value.divide(right.value, MATH_CONTEXT)
                        stage2.add(TokenItem.Num(divided))
                    } else {
                        val multiplied = left.value.multiply(right.value, MATH_CONTEXT)
                        stage2.add(TokenItem.Num(multiplied))
                    }
                    idx += 2
                } else {
                    stage2.add(current)
                    idx += 1
                }
            }

            // Stage 3: Low Precedence (+ and −)
            if (stage2.isEmpty() || stage2.first() !is TokenItem.Num) {
                return EvaluationResult(isSuccess = false, errorMessage = "Syntax error")
            }

            var accumulator = (stage2[0] as TokenItem.Num).value
            var s3Idx = 1

            while (s3Idx < stage2.size) {
                val opItem = stage2.getOrNull(s3Idx) as? TokenItem.Op
                val numItem = stage2.getOrNull(s3Idx + 1) as? TokenItem.Num

                if (opItem == null || numItem == null) {
                    return EvaluationResult(isSuccess = false, errorMessage = "Syntax error")
                }

                accumulator = when (opItem.operator) {
                    "+" -> accumulator.add(numItem.value, MATH_CONTEXT)
                    "−" -> accumulator.subtract(numItem.value, MATH_CONTEXT)
                    else -> return EvaluationResult(isSuccess = false, errorMessage = "Syntax error")
                }
                s3Idx += 2
            }

            val formatted = formatResult(accumulator)
            return EvaluationResult(
                isSuccess = true,
                formattedResult = formatted,
                rawValue = accumulator
            )
        } catch (e: ArithmeticException) {
            return EvaluationResult(isSuccess = false, errorMessage = "Cannot divide by zero")
        } catch (e: Exception) {
            return EvaluationResult(isSuccess = false, errorMessage = "Invalid format")
        }
    }
}
