package com.calculator.compose.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Tokens
val PrimaryLight = Color(0xFF006495)
val OnPrimaryLight = Color(0xFFFFFFFF)
val SecondaryLight = Color(0xFF50606E)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFD4E4F6)
val OnSecondaryContainerLight = Color(0xFF0C1D29)
val SurfaceLight = Color(0xFFF8F9FA)
val OnSurfaceLight = Color(0xFF191C1E)
val SurfaceVariantLight = Color(0xFFDEE3EB)
val OnSurfaceVariantLight = Color(0xFF42474E)
val SurfaceContainerHighLight = Color(0xFFE8ECF2)
val BackgroundLight = Color(0xFFFCFCFD)
val OnBackgroundLight = Color(0xFF191C1E)
val ErrorLight = Color(0xFFBA1A1A)

// Dark Theme Tokens
val PrimaryDark = Color(0xFF8BCEFF)
val OnPrimaryDark = Color(0xFF00344F)
val SecondaryDark = Color(0xFFB8C8D9)
val OnSecondaryDark = Color(0xFF22323F)
val SecondaryContainerDark = Color(0xFF384956)
val OnSecondaryContainerDark = Color(0xFFD4E4F6)
val SurfaceDark = Color(0xFF191C1E)
val OnSurfaceDark = Color(0xFFE2E2E5)
val SurfaceVariantDark = Color(0xFF42474E)
val OnSurfaceVariantDark = Color(0xFFC2C7CF)
val SurfaceContainerHighDark = Color(0xFF272A2D)
val BackgroundDark = Color(0xFF111416)
val OnBackgroundDark = Color(0xFFE2E2E5)
val ErrorDark = Color(0xFFFFB4AB)
