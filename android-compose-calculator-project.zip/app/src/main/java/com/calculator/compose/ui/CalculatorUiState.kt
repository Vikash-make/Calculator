package com.calculator.compose.ui

/**
 * Immutable State data class following Compose best practices.
 */
data class CalculationHistoryEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val expression: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class CalculatorUiState(
    val expression: String = "",
    val formattedDisplayExpression: String = "",
    val previewResult: String = "",
    val errorMessage: String? = null,
    val isEvaluated: Boolean = false,
    val historyList: List<CalculationHistoryEntry> = emptyList(),
    val isHistoryOpen: Boolean = false
) {
    /**
     * Determines whether to show the error message, preview, or blank
     */
    val displayPrimaryText: String
        get() = when {
            errorMessage != null -> errorMessage
            isEvaluated && previewResult.isNotEmpty() -> previewResult
            formattedDisplayExpression.isNotEmpty() -> formattedDisplayExpression
            else -> "0"
        }
}
