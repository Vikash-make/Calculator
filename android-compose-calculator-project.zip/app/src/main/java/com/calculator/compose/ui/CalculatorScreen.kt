package com.calculator.compose.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class ButtonRole {
    DIGIT,
    OPERATOR,
    UTILITY,
    EQUALS
}

data class KeypadKey(
    val text: String,
    val role: ButtonRole,
    val action: CalculatorAction,
    val contentDescription: String,
    val isIcon: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    viewModel: CalculatorViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()
    val haptic = LocalHapticFeedback.current

    // Auto-scroll to the end when expression changes
    LaunchedEffect(uiState.formattedDisplayExpression) {
        scrollState.animateScrollTo(scrollState.maxValue)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top App Bar Area with History & Title
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Calculator",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
                IconButton(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        viewModel.onAction(CalculatorAction.ToggleHistory)
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Calculation History",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Display Section (Top Area)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 12.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.End
            ) {
                // Secondary Ongoing / History Expression with Auto-Scroll
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = if (uiState.isEvaluated) uiState.formattedDisplayExpression else "",
                        style = MaterialTheme.typography.bodyLarge.copy(fontSize = 20.sp),
                        color = MaterialTheme.colorScheme.outline,
                        fontWeight = FontWeight.Normal,
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Primary Text Display (Large input or error or result)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.End
                ) {
                    val isError = uiState.errorMessage != null
                    Text(
                        text = uiState.displayPrimaryText,
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontSize = if (uiState.displayPrimaryText.length > 9) 38.sp else 52.sp,
                            fontWeight = FontWeight.Light,
                            letterSpacing = (-0.5).sp
                        ),
                        color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        textAlign = TextAlign.End
                    )
                }

                // Dynamic Live Preview beneath ongoing input
                if (!uiState.isEvaluated && uiState.previewResult.isNotEmpty() && uiState.errorMessage == null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "= " + uiState.previewResult,
                        style = MaterialTheme.typography.headlineSmall.copy(fontSize = 24.sp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                        fontWeight = FontWeight.Normal,
                        maxLines = 1
                    )
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(bottom = 12.dp),
                thickness = 0.5.dp,
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
            )

            // 4x5 Keypad Grid (Bottom Section)
            CalculatorKeypad(
                onKeyClick = { action ->
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    viewModel.onAction(action)
                }
            )
        }

        // Animated History Drawer Overlay
        AnimatedVisibility(
            visible = uiState.isHistoryOpen,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            HistorySheet(
                historyList = uiState.historyList,
                onClose = { viewModel.onAction(CalculatorAction.ToggleHistory) },
                onClear = { viewModel.onAction(CalculatorAction.ClearHistory) },
                onSelect = { viewModel.onAction(CalculatorAction.RecallHistory(it)) }
            )
        }
    }
}

@Composable
fun CalculatorKeypad(
    onKeyClick: (CalculatorAction) -> Unit,
    modifier: Modifier = Modifier
) {
    // 4 Columns x 5 Rows Layout
    val keys = listOf(
        // Row 1: Utilities
        listOf(
            KeypadKey("AC", ButtonRole.UTILITY, CalculatorAction.ClearAll, "Clear All"),
            KeypadKey("⌫", ButtonRole.UTILITY, CalculatorAction.Delete, "Backspace", isIcon = true),
            KeypadKey("%", ButtonRole.UTILITY, CalculatorAction.Percentage, "Percentage"),
            KeypadKey("÷", ButtonRole.OPERATOR, CalculatorAction.Operator("÷"), "Divide")
        ),
        // Row 2: 7, 8, 9, Multiply
        listOf(
            KeypadKey("7", ButtonRole.DIGIT, CalculatorAction.Number("7"), "Seven"),
            KeypadKey("8", ButtonRole.DIGIT, CalculatorAction.Number("8"), "Eight"),
            KeypadKey("9", ButtonRole.DIGIT, CalculatorAction.Number("9"), "Nine"),
            KeypadKey("×", ButtonRole.OPERATOR, CalculatorAction.Operator("×"), "Multiply")
        ),
        // Row 3: 4, 5, 6, Subtract
        listOf(
            KeypadKey("4", ButtonRole.DIGIT, CalculatorAction.Number("4"), "Four"),
            KeypadKey("5", ButtonRole.DIGIT, CalculatorAction.Number("5"), "Five"),
            KeypadKey("6", ButtonRole.DIGIT, CalculatorAction.Number("6"), "Six"),
            KeypadKey("−", ButtonRole.OPERATOR, CalculatorAction.Operator("−"), "Subtract")
        ),
        // Row 4: 1, 2, 3, Add
        listOf(
            KeypadKey("1", ButtonRole.DIGIT, CalculatorAction.Number("1"), "One"),
            KeypadKey("2", ButtonRole.DIGIT, CalculatorAction.Number("2"), "Two"),
            KeypadKey("3", ButtonRole.DIGIT, CalculatorAction.Number("3"), "Three"),
            KeypadKey("+", ButtonRole.OPERATOR, CalculatorAction.Operator("+"), "Add")
        ),
        // Row 5: ±, 0, ., Equals
        listOf(
            KeypadKey("±", ButtonRole.DIGIT, CalculatorAction.PlusMinus, "Plus Minus"),
            KeypadKey("0", ButtonRole.DIGIT, CalculatorAction.Number("0"), "Zero"),
            KeypadKey(".", ButtonRole.DIGIT, CalculatorAction.Decimal, "Decimal point"),
            KeypadKey("=", ButtonRole.EQUALS, CalculatorAction.Calculate, "Equals")
        )
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        keys.forEach { rowKeys ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowKeys.forEach { key ->
                    Box(modifier = Modifier.weight(1f)) {
                        CalculatorButton(
                            key = key,
                            onClick = { onKeyClick(key.action) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CalculatorButton(
    key: KeypadKey,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Dynamic color coding according to Material 3 specifications
    val (containerColor, contentColor) = when (key.role) {
        ButtonRole.DIGIT -> Pair(
            MaterialTheme.colorScheme.surfaceContainerHigh,
            MaterialTheme.colorScheme.onSurface
        )
        ButtonRole.OPERATOR -> Pair(
            MaterialTheme.colorScheme.secondaryContainer,
            MaterialTheme.colorScheme.onSecondaryContainer
        )
        ButtonRole.UTILITY -> Pair(
            MaterialTheme.colorScheme.surfaceVariant,
            MaterialTheme.colorScheme.onSurfaceVariant
        )
        ButtonRole.EQUALS -> Pair(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.onPrimary
        )
    }

    FilledTonalButton(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f),
        shape = CircleShape,
        colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        contentPadding = PaddingValues(0.dp),
        elevation = ButtonDefaults.filledTonalButtonElevation(
            defaultElevation = 0.dp,
            pressedElevation = 2.dp
        )
    ) {
        if (key.isIcon && key.text == "⌫") {
            Icon(
                imageVector = Icons.Default.Backspace,
                contentDescription = key.contentDescription,
                modifier = Modifier.size(24.dp)
            )
        } else {
            Text(
                text = key.text,
                fontSize = when {
                    key.role == ButtonRole.OPERATOR || key.role == ButtonRole.EQUALS -> 28.sp
                    key.text.length > 2 -> 18.sp
                    else -> 24.sp
                },
                fontWeight = if (key.role == ButtonRole.DIGIT) FontWeight.Normal else FontWeight.Medium
            )
        }
    }
}

@Composable
fun HistorySheet(
    historyList: List<CalculationHistoryEntry>,
    onClose: () -> Unit,
    onClear: () -> Unit,
    onSelect: (CalculationHistoryEntry) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.4f)),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "History",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.SemiBold
                )
                Row {
                    if (historyList.isNotEmpty()) {
                        IconButton(onClick = onClear) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Clear History",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (historyList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No history yet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(historyList, key = { it.id }) { item ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(item) },
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainer
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalAlignment = Alignment.End
                            ) {
                                Text(
                                    text = item.expression,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "= " + item.result,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
