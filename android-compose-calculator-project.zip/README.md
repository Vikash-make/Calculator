# Android Jetpack Compose Calculator

Production-ready Simple Calculator for Android built with Kotlin and Jetpack Compose.

## Highlights
- **Architecture**: Clean MVVM (Model-View-ViewModel) with StateFlow.
- **Engine**: Precise arithmetic with `java.math.BigDecimal` to prevent floating-point rounding errors.
- **Operations**: BODMAS / PEMDAS rule compliance (+, −, ×, ÷, %, backspace, AC).
- **Safety**: Robust handling for division by zero ("Cannot divide by zero"), operator stacking, and multiple decimal prevention.
- **UI/UX**: Material 3 (Material You) styling with dynamic color adaptation, high-contrast palette, and tactile ripple feedback.

## Requirements
- Android Studio Ladybug or later
- Android SDK 35 (compileSdk 35, minSdk 24)
- JDK 17
